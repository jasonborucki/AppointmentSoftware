IDE- IntelliJ IDEA 2021.3 (Community Edition)
JavaFX - SDK - 17.0.1
Java 17.0.1
MySQL Connector - 8.0.25

The title of this application is "Schedule Application." The purpose of this is to create a fully functional desktop application that handles all the potential problems faced by businesses needing real world scheduling solutions. Since the application is connected to a MySQL server, the data is stored online allowing the front end of the application to gather the information it needs whenever.

In order to run this program, you will need to compile the program. Afterwards, you will see a log in screen. Please use the following usernames and passwords to log in:

Username: test
password: test

Username: admin
password: admin

After logging in, the main screen(FirstScreen in the project) will display with all of the following functionalities:

1) View Customers
2) Add/Update/Delete Customers
3) Add/Update/Delete Appointments(Please select a customer before adding an appointment).
4) View Appointments in a few ways: All at once, by the current week, by the current month.
5) View various reports required in the rubric: By Contact- By Type-Month-Type and Month

In addition to the reports required by the rubric as well as the attached log-in activity textfile, I created another report that displays the current schedule of appointments per location while giving a count as well. This will be able to keep track of all locations and give a good overview of the activities occuring in all locations.
